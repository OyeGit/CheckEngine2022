package com.velexsoft.checkengine;

import android.support.v4.content.FileProvider;

/**
 * Created by ooyeg on 3/2/2018.
 */

public class GenericFileProvider extends FileProvider {
    public static final String PROVIDER_NAME = "com.velexsoft.checkengine.FILE_PROVIDER";
}
